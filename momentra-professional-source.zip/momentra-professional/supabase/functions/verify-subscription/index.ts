import { createClient } from 'npm:@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: cors });
async function hmacHex(secret: string, message: string) { const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']); return [...new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message)))].map(x => x.toString(16).padStart(2, '0')).join(''); }
function safeEqual(a: string, b: string) { if (a.length !== b.length) return false; let n = 0; for (let i = 0; i < a.length; i++) n |= a.charCodeAt(i) ^ b.charCodeAt(i); return n === 0; }
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const authHeader = req.headers.get('Authorization'); if (!authHeader) return json({ error: 'Sign in required' }, 401);
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const userClient = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userClient.auth.getUser(); if (!user) return json({ error: 'Sign in required' }, 401);
    const { razorpay_payment_id, razorpay_subscription_id, razorpay_signature } = await req.json();
    if (![razorpay_payment_id, razorpay_subscription_id, razorpay_signature].every(x => typeof x === 'string' && x.length > 0)) return json({ error: 'Payment verification details are incomplete' }, 400);
    const { data: studio } = await admin.from('studios').select('id').eq('owner_id', user.id).single(); if (!studio) return json({ error: 'Studio not found' }, 404);
    const { data: attempt } = await admin.from('payment_attempts').select('razorpay_subscription_id,billing_period,studio_id').eq('studio_id', studio.id).eq('razorpay_subscription_id', razorpay_subscription_id).single();
    if (!attempt) return json({ error: 'Subscription does not belong to this studio' }, 403);
    const keySecret = Deno.env.get('RAZORPAY_KEY_SECRET')!;
    const expected = await hmacHex(keySecret, `${razorpay_subscription_id}|${razorpay_payment_id}`);
    if (!safeEqual(expected, razorpay_signature)) return json({ error: 'Payment signature is invalid' }, 400);
    const keyId = Deno.env.get('RAZORPAY_KEY_ID')!;
    const response = await fetch(`https://api.razorpay.com/v1/subscriptions/${encodeURIComponent(razorpay_subscription_id)}`, { headers: { 'Authorization': `Basic ${btoa(`${keyId}:${keySecret}`)}` } });
    const subscription = await response.json();
    if (!response.ok || subscription.notes?.studio_id !== studio.id) return json({ error: 'Could not confirm subscription with Razorpay' }, 502);
    await admin.from('payment_attempts').update({ status: subscription.status || 'authenticated', updated_at: new Date().toISOString() }).eq('razorpay_subscription_id', razorpay_subscription_id);
    const { error } = await admin.from('billing_accounts').upsert({ studio_id: studio.id, razorpay_subscription_id, plan: 'studio', billing_period: attempt.billing_period, status: subscription.status || 'authenticated', current_period_end: subscription.current_end ? new Date(subscription.current_end * 1000).toISOString() : null, updated_at: new Date().toISOString() }, { onConflict: 'studio_id' });
    if (error) return json({ error: 'Payment received; subscription status will update shortly' }, 500);
    return json({ verified: true, status: subscription.status });
  } catch (e) { console.error('verify-subscription error', e); return json({ error: 'Unable to verify payment' }, 500); }
});
