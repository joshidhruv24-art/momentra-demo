import { createClient } from 'npm:@supabase/supabase-js@2';
async function hmacHex(secret: string, message: string) { const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']); return [...new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message)))].map(x => x.toString(16).padStart(2, '0')).join(''); }
function safeEqual(a: string, b: string) { if (a.length !== b.length) return false; let n = 0; for (let i = 0; i < a.length; i++) n |= a.charCodeAt(i) ^ b.charCodeAt(i); return n === 0; }
Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const raw = await req.text(); const signature = req.headers.get('x-razorpay-signature') || '';
  const expected = await hmacHex(Deno.env.get('RAZORPAY_WEBHOOK_SECRET')!, raw);
  if (!safeEqual(expected, signature)) return new Response('Invalid signature', { status: 400 });
  try {
    const event = JSON.parse(raw); const entity = event.payload?.subscription?.entity;
    if (!entity?.id) return Response.json({ received: true });
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: attempt } = await admin.from('payment_attempts').select('studio_id,billing_period').eq('razorpay_subscription_id', entity.id).maybeSingle();
    const studioId = attempt?.studio_id || entity.notes?.studio_id;
    const patch = { razorpay_subscription_id: entity.id, plan: 'studio', billing_period: attempt?.billing_period || entity.notes?.billing_period || null, status: entity.status || event.event, current_period_end: entity.current_end ? new Date(entity.current_end * 1000).toISOString() : null, updated_at: new Date().toISOString() };
    if (attempt) await admin.from('payment_attempts').update({ status: entity.status || event.event, updated_at: new Date().toISOString() }).eq('razorpay_subscription_id', entity.id);
    if (studioId && ['active','authenticated','halted','cancelled','completed','paused'].includes(patch.status)) await admin.from('billing_accounts').upsert({ studio_id: studioId, ...patch }, { onConflict: 'studio_id' });
    return Response.json({ received: true });
  } catch (e) { console.error('razorpay-webhook error', e); return new Response('Webhook processing failed', { status: 500 }); }
});
