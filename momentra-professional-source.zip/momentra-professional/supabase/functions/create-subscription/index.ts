import { createClient } from 'npm:@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: cors });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return json({ error: 'Sign in required' }, 401);
    const url = Deno.env.get('SUPABASE_URL')!;
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) return json({ error: 'Sign in required' }, 401);
    const { data: studio } = await admin.from('studios').select('id,name').eq('owner_id', user.id).single();
    if (!studio) return json({ error: 'Create a studio before checkout' }, 400);
    const { period } = await req.json();
    const planEnv: Record<string, string> = { monthly: 'RAZORPAY_PLAN_MONTHLY', quarterly: 'RAZORPAY_PLAN_QUARTERLY', yearly: 'RAZORPAY_PLAN_YEARLY' };
    if (!(period in planEnv)) return json({ error: 'Choose monthly, quarterly or yearly billing' }, 400);
    const planId = Deno.env.get(planEnv[period]);
    const keyId = Deno.env.get('RAZORPAY_KEY_ID');
    const keySecret = Deno.env.get('RAZORPAY_KEY_SECRET');
    if (!planId || !keyId || !keySecret) return json({ error: 'Razorpay is not configured. Add the three plan IDs and API credentials in Supabase.' }, 503);
    const allowed = (Deno.env.get('ALLOWED_APP_ORIGINS') || '').split(',').map(x => x.trim()).filter(Boolean);
    if (!allowed.includes(req.headers.get('origin') || '')) return json({ error: 'Website origin is not allowed' }, 403);
    const response = await fetch('https://api.razorpay.com/v1/subscriptions', { method: 'POST', headers: { 'Authorization': `Basic ${btoa(`${keyId}:${keySecret}`)}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ plan_id: planId, total_count: 120, customer_notify: 1, notes: { studio_id: studio.id, owner_id: user.id, billing_period: period } }) });
    const subscription = await response.json();
    if (!response.ok) { console.error('Razorpay subscription create failed', response.status, subscription?.error?.code); return json({ error: 'Razorpay could not create the subscription. Check your plan and API key configuration.' }, 502); }
    const { error: dbError } = await admin.from('payment_attempts').insert({ razorpay_subscription_id: subscription.id, studio_id: studio.id, billing_period: period, status: subscription.status || 'created' });
    if (dbError) { console.error('payment attempt save failed', dbError.message); return json({ error: 'Unable to save subscription. Contact support before retrying.' }, 500); }
    return json({ subscription_id: subscription.id, key_id: keyId, studio_name: studio.name });
  } catch (e) { console.error('create-subscription error', e); return json({ error: 'Unable to start Razorpay checkout' }, 500); }
});
