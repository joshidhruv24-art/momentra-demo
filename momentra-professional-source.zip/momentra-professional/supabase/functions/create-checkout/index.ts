import Stripe from 'npm:stripe@^22';
import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return Response.json({ error: 'Sign in required' }, { status: 401, headers: cors });
    const url = Deno.env.get('SUPABASE_URL')!;
    const anon = Deno.env.get('SUPABASE_ANON_KEY')!;
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const userClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) return Response.json({ error: 'Sign in required' }, { status: 401, headers: cors });
    const { data: studio } = await admin.from('studios').select('id,name').eq('owner_id', user.id).single();
    if (!studio) return Response.json({ error: 'Create a studio before checkout' }, { status: 400, headers: cors });
    const body = await req.json();
    const kind = body.kind === 'event' ? 'event' : 'studio';
    const price = Deno.env.get(kind === 'event' ? 'STRIPE_EVENT_PRICE_ID' : 'STRIPE_STUDIO_PRICE_ID');
    if (!price) return Response.json({ error: 'Payment plan is not configured' }, { status: 503, headers: cors });
    const origin = req.headers.get('origin') || '';
    const appBase = Deno.env.get('APP_BASE_URL') || '';
    const allowed = (Deno.env.get('ALLOWED_APP_ORIGINS') || '').split(',').map(x => x.trim()).filter(Boolean);
    if (!allowed.includes(origin) || new URL(appBase).origin !== origin) return Response.json({ error: 'Website origin is not allowed' }, { status: 403, headers: cors });
    const stripe = new Stripe(Deno.env.get('STRIPE_API_KEY')!, { httpClient: Stripe.createFetchHttpClient() });
    const { data: billing } = await admin.from('billing_accounts').select('stripe_customer_id').eq('studio_id', studio.id).maybeSingle();
    const session = await stripe.checkout.sessions.create({
      mode: kind === 'studio' ? 'subscription' : 'payment',
      line_items: [{ price, quantity: 1 }],
      customer: billing?.stripe_customer_id || undefined,
      customer_email: billing?.stripe_customer_id ? undefined : user.email,
      client_reference_id: studio.id,
      metadata: { studio_id: studio.id, user_id: user.id, kind },
      subscription_data: kind === 'studio' ? { metadata: { studio_id: studio.id, kind } } : undefined,
      success_url: `${appBase.replace(/\/$/, '')}/?payment=success`,
      cancel_url: `${appBase.replace(/\/$/, '')}/?payment=cancelled`
    });
    return Response.json({ url: session.url }, { headers: cors });
  } catch (e) {
    console.error('checkout error', e);
    return Response.json({ error: 'Unable to start checkout' }, { status: 500, headers: cors });
  }
});
