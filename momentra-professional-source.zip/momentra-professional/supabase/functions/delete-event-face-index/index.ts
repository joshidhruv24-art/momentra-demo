import { createClient } from 'npm:@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: cors });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const auth = req.headers.get('Authorization'); if (!auth) return json({ error: 'Sign in required' }, 401);
    const url = Deno.env.get('SUPABASE_URL')!;
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await userClient.auth.getUser(); if (!user) return json({ error: 'Sign in required' }, 401);
    const { event_id } = await req.json(); if (typeof event_id !== 'string') return json({ error: 'Event is required' }, 400);
    const { data: event } = await admin.from('events').select('id,studio_id').eq('id', event_id).maybeSingle();
    if (!event) return json({ error: 'Event not found' }, 404);
    const { data: studio } = await admin.from('studios').select('id').eq('id', event.studio_id).eq('owner_id', user.id).maybeSingle();
    if (!studio) return json({ error: 'Event does not belong to this studio' }, 403);
    const { error } = await admin.from('photo_faces').delete().eq('event_id', event.id);
    if (error) return json({ error: 'Unable to delete face index' }, 500);
    return json({ deleted: true });
  } catch (error) { console.error('delete-event-face-index', error); return json({ error: 'Unable to delete face index' }, 500); }
});
