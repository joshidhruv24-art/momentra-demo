import { createClient } from 'npm:@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: { ...cors, 'Cache-Control': 'no-store' } });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const body = await req.json();
    if (body.consent !== true || typeof body.share_token !== 'string' || !Array.isArray(body.descriptor) || body.descriptor.length !== 128 || body.descriptor.some((x: unknown) => typeof x !== 'number' || !Number.isFinite(x))) return json({ error: 'Consent and a valid face descriptor are required' }, 400);
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: event } = await admin.from('events').select('id,face_indexing_consented,status,expires_at').eq('share_token', body.share_token).maybeSingle();
    if (!event || event.status !== 'ready' || new Date(event.expires_at).getTime() <= Date.now()) return json({ error: 'This event link has expired or is unavailable' }, 404);
    if (!event.face_indexing_consented) return json({ error: 'Face search is not enabled for this event' }, 403);
    const vector = `[${body.descriptor.join(',')}]`;
    const { data: matches, error } = await admin.rpc('match_event_faces', { p_event_id: event.id, p_embedding: vector, p_max_distance: 0.52, p_limit: 100 });
    if (error) { console.error('face search rpc', error.message); return json({ error: 'Face search is temporarily unavailable' }, 503); }
    const ids = [...new Set((matches || []).map((x: { photo_id: string }) => x.photo_id))];
    if (!ids.length) return json({ photos: [] });
    const { data: photos } = await admin.from('photos').select('id,filename,original_path,corrected_path').eq('event_id', event.id).in('id', ids);
    const storage = admin.storage.from('momentra-originals');
    const signed = await Promise.all((photos || []).map(async (photo) => {
      const path = photo.corrected_path || photo.original_path;
      const { data } = await storage.createSignedUrl(path, 180);
      return data?.signedUrl ? { id: photo.id, filename: photo.filename, url: data.signedUrl } : null;
    }));
    return json({ photos: signed.filter(Boolean) });
  } catch (error) { console.error('guest-face-search', error); return json({ error: 'Face search failed' }, 500); }
});
