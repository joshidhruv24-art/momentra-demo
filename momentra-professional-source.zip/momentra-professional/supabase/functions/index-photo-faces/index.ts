import { createClient } from 'npm:@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: cors });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const auth = req.headers.get('Authorization'); if (!auth) return json({ error: 'Sign in required' }, 401);
    const url = Deno.env.get('SUPABASE_URL')!;
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await userClient.auth.getUser(); if (!user) return json({ error: 'Sign in required' }, 401);
    const body = await req.json();
    if (typeof body.event_id !== 'string' || typeof body.photo_id !== 'string' || !Array.isArray(body.descriptors) || body.descriptors.length > 40) return json({ error: 'Invalid face index request' }, 400);
    if (body.descriptors.some((d: unknown) => !Array.isArray(d) || d.length !== 128 || d.some((x: unknown) => typeof x !== 'number' || !Number.isFinite(x)))) return json({ error: 'Invalid face descriptor' }, 400);
    const { data: event } = await admin.from('events').select('id,face_indexing_consented,studio_id').eq('id', body.event_id).maybeSingle();
    if (!event?.face_indexing_consented) return json({ error: 'Face indexing is not enabled for this event' }, 403);
    const { data: studio } = await admin.from('studios').select('id').eq('id', event.studio_id).eq('owner_id', user.id).maybeSingle();
    if (!studio) return json({ error: 'Event does not belong to this studio' }, 403);
    const { data: photo } = await admin.from('photos').select('id,event_id').eq('id', body.photo_id).eq('event_id', event.id).maybeSingle();
    if (!photo) return json({ error: 'Photo does not belong to this event' }, 404);
    await admin.from('photo_faces').delete().eq('photo_id', photo.id);
    if (body.descriptors.length) {
      const rows = body.descriptors.map((values: number[]) => ({ studio_id: studio.id, event_id: event.id, photo_id: photo.id, descriptor: `[${values.join(',')}]` }));
      const { error } = await admin.from('photo_faces').insert(rows);
      if (error) return json({ error: 'Unable to save face index' }, 500);
    }
    return json({ indexed_faces: body.descriptors.length });
  } catch (error) { console.error('index-photo-faces', error); return json({ error: 'Unable to index photo faces' }, 500); }
});
