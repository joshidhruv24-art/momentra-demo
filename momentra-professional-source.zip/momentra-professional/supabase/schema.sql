-- Run once in the Supabase SQL editor. All studio data is private by default.
create extension if not exists pgcrypto;

create table if not exists public.studios (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null default 'My Studio',
  logo_url text,
  brand_color text not null default '#315d49',
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  studio_id uuid not null references public.studios(id) on delete cascade,
  title text not null,
  event_date date,
  expires_at timestamptz not null default (now() + interval '30 days'),
  share_token uuid not null unique default gen_random_uuid(),
  status text not null default 'ready' check (status in ('ready','processing','expired','archived')),
  created_at timestamptz not null default now()
);

create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(),
  studio_id uuid not null references public.studios(id) on delete cascade,
  event_id uuid not null references public.events(id) on delete cascade,
  original_path text not null,
  corrected_path text,
  filename text not null,
  mime_type text not null,
  size_bytes bigint not null check (size_bytes > 0),
  status text not null default 'uploaded' check (status in ('uploaded','processing','ready','failed','deleted')),
  created_at timestamptz not null default now(),
  unique(event_id, original_path)
);

create table if not exists public.billing_accounts (
  studio_id uuid primary key references public.studios(id) on delete cascade,
  razorpay_subscription_id text unique,
  plan text not null default 'free',
  billing_period text check (billing_period in ('monthly','quarterly','yearly')),
  status text not null default 'inactive',
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);

alter table public.studios enable row level security;
alter table public.events enable row level security;
alter table public.photos enable row level security;
alter table public.billing_accounts enable row level security;

create policy "Studio owner reads own studio" on public.studios for select to authenticated using (owner_id = (select auth.uid()));
create policy "Studio owner creates own studio" on public.studios for insert to authenticated with check (owner_id = (select auth.uid()));
create policy "Studio owner updates own studio" on public.studios for update to authenticated using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));

create policy "Studio owner manages own events" on public.events for all to authenticated
 using (studio_id in (select id from public.studios where owner_id = (select auth.uid())))
 with check (studio_id in (select id from public.studios where owner_id = (select auth.uid())));
create policy "Studio owner manages own photos" on public.photos for all to authenticated
 using (studio_id in (select id from public.studios where owner_id = (select auth.uid())))
 with check (studio_id in (select id from public.studios where owner_id = (select auth.uid())));
create policy "Studio owner reads billing status" on public.billing_accounts for select to authenticated
 using (studio_id in (select id from public.studios where owner_id = (select auth.uid())));

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('momentra-originals','momentra-originals',false,52428800,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=false, file_size_limit=52428800, allowed_mime_types=array['image/jpeg','image/png','image/webp'];

create policy "Studio owner uploads originals" on storage.objects for insert to authenticated
 with check (bucket_id='momentra-originals' and (storage.foldername(name))[1] in (select id::text from public.studios where owner_id=(select auth.uid())));
create policy "Studio owner reads originals" on storage.objects for select to authenticated
 using (bucket_id='momentra-originals' and (storage.foldername(name))[1] in (select id::text from public.studios where owner_id=(select auth.uid())));
create policy "Studio owner deletes originals" on storage.objects for delete to authenticated
 using (bucket_id='momentra-originals' and (storage.foldername(name))[1] in (select id::text from public.studios where owner_id=(select auth.uid())));

-- Face templates are deliberately absent until a specific processor, consent retention, and deletion policy are selected.

-- If upgrading an earlier preview database, run these migration statements once.
alter table public.billing_accounts add column if not exists razorpay_subscription_id text unique;
alter table public.billing_accounts add column if not exists billing_period text;


-- Private payment attempts let a cancelled checkout leave an existing paid plan untouched.
create table if not exists public.payment_attempts (
  razorpay_subscription_id text primary key,
  studio_id uuid not null references public.studios(id) on delete cascade,
  billing_period text not null check (billing_period in ('monthly','quarterly','yearly')),
  status text not null default 'created',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.payment_attempts enable row level security;
