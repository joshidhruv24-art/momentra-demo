-- Face search stores only 128-value descriptors, never guest selfie files.
-- Enable per event only when the studio confirms appropriate notice/permission.
create extension if not exists vector with schema extensions;
alter table public.events add column if not exists face_indexing_consented boolean not null default false;

create table if not exists public.photo_faces (
  id uuid primary key default gen_random_uuid(),
  studio_id uuid not null references public.studios(id) on delete cascade,
  event_id uuid not null references public.events(id) on delete cascade,
  photo_id uuid not null references public.photos(id) on delete cascade,
  descriptor extensions.vector(128) not null,
  created_at timestamptz not null default now()
);
create index if not exists photo_faces_event_idx on public.photo_faces(event_id);
create index if not exists photo_faces_descriptor_idx on public.photo_faces using hnsw (descriptor extensions.vector_l2_ops);
alter table public.photo_faces enable row level security;
revoke all on public.photo_faces from anon, authenticated;
grant all on public.photo_faces to service_role;

create or replace function public.match_event_faces(
  p_event_id uuid,
  p_embedding extensions.vector(128),
  p_max_distance real default 0.52,
  p_limit integer default 200
) returns table(photo_id uuid, distance real)
language sql stable security invoker
set search_path = ''
as $$
  select ranked.photo_id, ranked.distance
  from (
    select distinct on (pf.photo_id) pf.photo_id,
      (pf.descriptor <-> p_embedding)::real as distance
    from public.photo_faces pf
    join public.photos p on p.id = pf.photo_id and p.event_id = pf.event_id
    where pf.event_id = p_event_id and p.status = 'ready'
      and (pf.descriptor <-> p_embedding) < p_max_distance
    order by pf.photo_id, pf.descriptor <-> p_embedding
  ) ranked
  order by ranked.distance
  limit least(greatest(p_limit, 1), 200)
$$;
revoke all on function public.match_event_faces(uuid, extensions.vector, real, integer) from public, anon, authenticated;
grant execute on function public.match_event_faces(uuid, extensions.vector, real, integer) to service_role;
