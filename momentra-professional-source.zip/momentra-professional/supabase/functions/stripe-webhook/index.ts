import Stripe from 'npm:stripe@^22';
import { createClient } from 'npm:@supabase/supabase-js@2';

Deno.serve(async (req) => {
  const stripe = new Stripe(Deno.env.get('STRIPE_API_KEY')!, { httpClient: Stripe.createFetchHttpClient() });
  const signature = req.headers.get('stripe-signature');
  if (!signature) return new Response('Missing signature', { status: 400 });
  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(await req.text(), signature, Deno.env.get('STRIPE_WEBHOOK_SECRET')!, undefined, Stripe.createSubtleCryptoProvider());
  } catch (e) {
    console.error('invalid Stripe signature', e);
    return new Response('Invalid signature', { status: 400 });
  }
  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    const studioId = session.metadata?.studio_id;
    if (studioId) await admin.from('billing_accounts').upsert({ studio_id: studioId, stripe_customer_id: String(session.customer || ''), stripe_subscription_id: session.subscription ? String(session.subscription) : null, plan: session.metadata?.kind || 'event', status: 'active', updated_at: new Date().toISOString() });
  }
  if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted') {
    const sub = event.data.object as Stripe.Subscription;
    const studioId = sub.metadata?.studio_id;
    if (studioId) await admin.from('billing_accounts').upsert({ studio_id: studioId, stripe_customer_id: String(sub.customer), stripe_subscription_id: sub.id, plan: 'studio', status: sub.status, current_period_end: new Date(sub.current_period_end * 1000).toISOString(), updated_at: new Date().toISOString() });
  }
  return Response.json({ received: true });
});
